# -*- coding:ANSI-*-
[maincode]
exit()
